
// Hostname and port of backend
export const HOST_NAME = 'http://120.55.40.153:19900'